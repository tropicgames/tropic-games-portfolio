/*
 * This file is part of Playgama Bridge.
 *
 * Playgama Bridge is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 *
 * Playgama Bridge is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with Playgama Bridge. If not, see <https://www.gnu.org/licenses/>.
 */

import eventBus, { applyEventBusMixin } from '../../lib/EventBus'
import ModuleBase, { type PlatformBridgeLike } from '../ModuleBase'
import { EVENT_NAME } from '../../constants'
import {
    DEVICE_ORIENTATION,
    DEVICE_TYPE,
    type DeviceType,
    type DeviceOs,
    type DeviceOrientation,
} from './constants'
import { createOrientationOverlay } from './orientationOverlay'
import { detectOrientation } from './orientation'
import bridgeConfig from '../../lib/bridge-config'
import { SafeArea, type SafeAreaInsets } from '../../lib/safe-area'
import type { EventEmitter } from '../../lib/EventBus'

export interface DeviceConfig {
    useBuiltInOrientationPopup?: boolean
    supportedOrientations?: DeviceOrientation[]
    [key: string]: unknown
}

export interface DeviceBridgeOptions {
    device?: DeviceConfig
    [key: string]: unknown
}

export interface DeviceBridgeContract extends PlatformBridgeLike {
    deviceType: DeviceType
    deviceOs: DeviceOs
    safeArea?: SafeAreaInsets | null
    options: DeviceBridgeOptions
}

interface DeviceModule extends EventEmitter {}

class DeviceModule extends ModuleBase<DeviceBridgeContract> {
    get type(): DeviceType {
        return this._platformBridge.deviceType
    }

    get os(): DeviceOs {
        return this._platformBridge.deviceOs
    }

    get orientation(): DeviceOrientation | null {
        return this.#currentOrientation
    }

    get safeArea(): SafeAreaInsets {
        return this._platformBridge.safeArea ?? SafeArea.getInsets()
    }

    #currentOrientation: DeviceOrientation | null = null

    #overlayElement: HTMLDivElement | null = null

    #supportedOrientations: DeviceOrientation[] | null = null

    #useBuiltInOverlay = false

    #lastScreenWidth = 0

    #lastScreenHeight = 0

    #resizeDebounceTimer: ReturnType<typeof setTimeout> | null = null

    initialize(platformBridge: DeviceBridgeContract): this {
        super.initialize(platformBridge)
        this.#initializeOrientationTracking()
        this.#initializeScreenSizeTracking()
        return this
    }

    #initializeOrientationTracking(): void {
        this.#currentOrientation = detectOrientation()

        if (window.screen.orientation) {
            window.screen.orientation.addEventListener('change', () => this.#handleOrientationChange())
        } else {
            window.addEventListener('orientationchange', () => this.#handleOrientationChange())
        }
        window.addEventListener('resize', () => this.#handleOrientationChange())

        this.#initializeOrientationOverlay()
    }

    #initializeOrientationOverlay(): void {
        const { deviceType } = this._platformBridge
        const isMobileDevice = deviceType === DEVICE_TYPE.MOBILE || deviceType === DEVICE_TYPE.TABLET

        if (!isMobileDevice) {
            return
        }

        const deviceConfig = bridgeConfig.getValues().device
        this.#useBuiltInOverlay = deviceConfig?.useBuiltInOrientationPopup ?? false
        this.#supportedOrientations = deviceConfig?.supportedOrientations ?? [
            DEVICE_ORIENTATION.PORTRAIT,
            DEVICE_ORIENTATION.LANDSCAPE,
        ]

        this.#updateOverlay()
    }

    #handleOrientationChange(): void {
        const newOrientation = detectOrientation()
        if (newOrientation !== this.#currentOrientation) {
            this.#currentOrientation = newOrientation
            eventBus.emit(EVENT_NAME.ORIENTATION_STATE_CHANGED, this.#currentOrientation)
            this.#updateOverlay()
        }
    }

    #updateOverlay(): void {
        if (!this.#useBuiltInOverlay) {
            return
        }

        if (!this.#supportedOrientations || this.#supportedOrientations.length !== 1) {
            this.#hideOverlay()
            return
        }

        const supportedOrientation = this.#supportedOrientations[0]
        if (this.#currentOrientation !== supportedOrientation) {
            this.#showOverlay()
        } else {
            this.#hideOverlay()
        }
    }

    #showOverlay(): void {
        if (this.#overlayElement) {
            return
        }
        this.#overlayElement = createOrientationOverlay()
        document.body.appendChild(this.#overlayElement)
    }

    #hideOverlay(): void {
        if (this.#overlayElement) {
            this.#overlayElement.remove()
            this.#overlayElement = null
        }
    }

    #initializeScreenSizeTracking(): void {
        this.#lastScreenWidth = window.innerWidth
        this.#lastScreenHeight = window.innerHeight
        window.addEventListener('resize', () => this.#handleScreenSizeChange())
    }

    #handleScreenSizeChange(): void {
        if (this.#resizeDebounceTimer) {
            clearTimeout(this.#resizeDebounceTimer)
        }

        this.#resizeDebounceTimer = setTimeout(() => {
            const newWidth = window.innerWidth
            const newHeight = window.innerHeight

            if (newWidth !== this.#lastScreenWidth || newHeight !== this.#lastScreenHeight) {
                this.#lastScreenWidth = newWidth
                this.#lastScreenHeight = newHeight
                eventBus.emit(EVENT_NAME.SCREEN_SIZE_CHANGED, { width: newWidth, height: newHeight })
            }
        }, 200)
    }
}

applyEventBusMixin(DeviceModule.prototype)
export default DeviceModule
