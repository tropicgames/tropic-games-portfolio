/*
 * This file is part of Playgama Bridge.
 *
 * Playgama Bridge is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 *
 * Playgama Bridge is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with Playgama Bridge. If not, see <https://www.gnu.org/licenses/>.
 */

import type { PlatformBridgeLike } from '../ModuleBase'
import type { PlatformId } from '../platform/constants'
import type { AnyRecord } from '../../utils'
import type { PostRewardType } from './constants'

// Social methods that resolve their data from the config mapping.
export type SocialMethod = 'share' | 'inviteFriends' | 'joinCommunity' | 'createPost'

// Content the game passes at call time. `text`/`image`/`url` are the canonical,
// platform-agnostic fields each bridge maps to its native one (e.g. VK `url` ->
// `link`, Discord `image` -> `mediaUrl`); `image` accepts a base64 data-URI or an
// URL and the bridge converts as needed. Any OTHER key is forwarded verbatim to the
// platform SDK call, so games/config can pass raw platform-specific fields
// (VK `attachments`, OK `media` polls, Facebook `intent`, ...) without an SDK change.
export interface SocialOptions extends AnyRecord {
    text?: string
    image?: string
    url?: string
}

// One reward declared for a post. Data-only, mirroring the tasks module: `id`
// and `amount` are opaque to the bridge — the game decides what they mean and
// grants them. `type` says who gets it; without it the reward is for the player
// who came to the game through the post.
export interface PostRewardConfig {
    id: string
    amount: number
    type?: PostRewardType
}

// Travels with a post and comes back when someone opens it.
export interface PostLaunchOptions {
    id?: string
    payload?: string
}

// A reward social.getPostReward() hands to the game. For the author the amount
// is already multiplied by the number of players the backend counted.
export interface PostReward {
    id: string
    amount: number
    type: PostRewardType
}

// Config entry a social method reads by id: `social.shares` for share(),
// `social.invites` for inviteFriends(), `social.posts` for createPost(). A key
// named after a platform holds that platform's fields and overrides the common ones.
export interface SocialContentMapping extends AnyRecord {
    id: string
    text?: string
    image?: string
    url?: string
}

export type ShareMapping = SocialContentMapping

export type InviteMapping = SocialContentMapping

// Entry of `social.posts`: the content plus what the post grants, see
// social.getPostReward().
export interface PostMapping extends SocialContentMapping {
    rewards?: PostRewardConfig[]
    // Seconds the same player waits before the next post visit reward, verified
    // by the platform backend. The wait is counted per player across all posts
    // of the game, so opening ten posts in a row does not multiply the reward.
    // Omit it for a one-time reward.
    rewardCooldown?: number
}

// Per-method config block: the social data for one method (publisher settings like
// community ids/page flags, optional defaults for the canonical content fields, and
// `native`). It is platform-resolved before the module reads it: put common values
// in the top-level `social[method]` block and platform-specific overrides in
// `platforms[id].social[method]` — the config loader deep-merges them. So there is
// no platform key here; the game can still override any of it at call time.
// A method called with an id reads its config entry instead of this block.
export type SocialMethodConfig = SocialOptions

export interface SocialConfig {
    share?: SocialMethodConfig
    inviteFriends?: SocialMethodConfig
    joinCommunity?: SocialMethodConfig
    createPost?: SocialMethodConfig
    // Entries the methods read when called with an id.
    shares?: ShareMapping[]
    invites?: InviteMapping[]
    posts?: PostMapping[]
}

export interface SocialBridgeOptions extends AnyRecord {
    social?: SocialConfig
}

export interface SocialBridgeContract extends PlatformBridgeLike {
    platformId: PlatformId
    options: SocialBridgeOptions
    isInviteFriendsSupported: boolean
    isJoinCommunitySupported: boolean
    isShareSupported: boolean
    isCreatePostSupported: boolean
    isAddToHomeScreenSupported: boolean
    isAddToHomeScreenRewardSupported: boolean
    isAddToFavoritesSupported: boolean
    isAddToFavoritesRewardSupported: boolean
    isRateSupported: boolean
    isPostRewardSupported: boolean
    launchPostId: string | null
    inviteFriends(data?: AnyRecord): Promise<unknown>
    joinCommunity(data?: AnyRecord): Promise<unknown>
    share(data?: AnyRecord): Promise<unknown>
    // What the post carries besides its content: the id of the config entry it
    // was created from and the game's own payload string. Both are kept out of
    // `data` so that nothing but content reaches the platform SDK, and both come
    // back when someone opens the post, as launchPostId and platformPayload.
    createPost(data?: AnyRecord, post?: PostLaunchOptions): Promise<unknown>
    addToHomeScreen(): Promise<unknown>
    getAddToHomeScreenReward(): Promise<unknown>
    addToFavorites(): Promise<unknown>
    getAddToFavoritesReward(): Promise<unknown>
    rate(): Promise<unknown>
    // The two sides of a post reward are two different calls to the platform
    // backend, so the bridge keeps them apart. The game sees one method:
    // SocialModule.getPostReward() picks the side by the launch post and turns
    // the answer into the rewards declared in the config entry.
    getPostVisitReward(cooldown?: number): Promise<unknown>
    // Players counted on the current player's posts since the previous call,
    // keyed by the config entry id of the post they came through.
    getPostAuthorReward(): Promise<Record<string, number>>
}
