import path from 'path'
import fs from 'fs'
import webpack, { Configuration, Compiler } from 'webpack'
import 'webpack-dev-server'
import ESLintPlugin from 'eslint-webpack-plugin'
import TerserPlugin from 'terser-webpack-plugin'
import packageJson from './package.json'
import { ALL_PLATFORM_IDS, expandPlatforms } from './scripts/platforms'

const platformDirName = 'platform-bridges'
const moduleDirName = 'modules'

class CleanChunksPlugin {
    apply(compiler: Compiler): void {
        compiler.hooks.beforeRun.tap('CleanChunksPlugin', () => {
            [platformDirName, moduleDirName].forEach((dirName) => {
                const chunksDir = path.resolve(__dirname, `dist/${dirName}`)
                if (fs.existsSync(chunksDir)) {
                    fs.rmSync(chunksDir, { recursive: true })
                }
            })
        })
    }
}

const createPlatformDefines = (targetPlatforms: string[]): Record<string, boolean> => {
    const includeAll = targetPlatforms.length === 0
    return Object.fromEntries(
        ALL_PLATFORM_IDS.map((id) => [
            `__INCLUDE_${id.toUpperCase()}__`,
            includeAll || targetPlatforms.includes(id),
        ]),
    )
}

interface CreateConfigOptions {
    noLint?: boolean
}

const createConfig = (targetPlatforms: string[] = [], { noLint = false }: CreateConfigOptions = {}): Configuration => ({
    mode: 'production',
    entry: './src/index',
    output: {
        // Pinned so the chunk registration global (webpackChunkplaygama_bridge)
        // never changes with the npm package name — a mismatch between cached
        // main bundle and chunks breaks lazy platform loading with ChunkLoadError.
        uniqueName: 'playgama-bridge',
        filename: 'playgama-bridge.js',
        chunkFilename: (pathData) => {
            // Lazy modules are named with webpackChunkName, platform chunks are not
            const chunkName = pathData.chunk?.name
            if (chunkName) {
                return `${moduleDirName}/${chunkName}.js`
            }
            const chunkId = String(pathData.chunk?.id || pathData.chunk?.name || '')
            const platformDirNameRegex = new RegExp(`${platformDirName}_(\\w+)_(?:ts|js)`)
            const match = chunkId.match(platformDirNameRegex)
            if (match) {
                const name = match[1]
                    .replace(/PlatformBridge/, '')
                    .replace(/([A-Z])/g, '-$1')
                    .replace(/-/g, '')
                    .toLowerCase()
                return `${platformDirName}/${name}.js`
            }
            return `${platformDirName}/${chunkId}.js`
        },
        path: path.resolve(__dirname, 'dist'),
        publicPath: 'auto',
    },
    resolve: {
        extensions: ['.ts', '.tsx', '.js', '.mjs'],
    },
    module: {
        rules: [
            {
                test: /\.m?js$/,
                exclude: /(node_modules|bower_components)/,
                use: {
                    loader: 'babel-loader',
                    options: {
                        presets: ['@babel/preset-env'],
                    },
                },
            },
            {
                test: /\.tsx?$/,
                exclude: /(node_modules|bower_components)/,
                use: {
                    loader: 'ts-loader',
                    options: {
                        transpileOnly: true,
                    },
                },
            },
        ],
    },
    optimization: {
        chunkIds: 'named',
        minimizer: [
            new TerserPlugin({
                extractComments: false,
                terserOptions: {
                    format: {
                        comments: false,
                    },
                },
            }),
        ],
        splitChunks: {
            chunks: 'async',
            cacheGroups: {
                default: false,
                defaultVendors: false,
            },
        },
    },
    plugins: [
        new CleanChunksPlugin(),
        ...noLint ? [] : [new ESLintPlugin({ extensions: ['js', 'ts', 'tsx'] })],
        new webpack.DefinePlugin({
            PLUGIN_VERSION: JSON.stringify(packageJson.version),
            // Kept as the historical, unscoped plugin name so it stays stable
            // regardless of the npm package name (which is scoped: @playgama/bridge).
            // This value is reported to platform SDKs (e.g. Yandex telemetry).
            PLUGIN_NAME: JSON.stringify('playgama-bridge'),
            ...createPlatformDefines(targetPlatforms),
        }),
    ],
    devServer: {
        port: 3535,
    },
})

interface WebpackEnv {
    platform?: string
    noLint?: boolean
    // Build the npm-consumable bundles (ESM + UMD) instead of the CDN builds.
    npm?: boolean
    // Absolute URL the dynamic bundle uses to fetch its platform-bridges/ and modules/ chunks.
    // Should match the deploy location, e.g. https://<domain>/v<major>/<channel>/
    publicPath?: string
}

interface WebpackArgv {
    mode?: string
}

export default (env: WebpackEnv = {}, argv: WebpackArgv = {}): Configuration | Configuration[] => {
    const targetPlatform = env.platform || ''
    const targetPlatforms = targetPlatform ? expandPlatforms(targetPlatform.split(',')) : []
    const noLint = Boolean(env.noLint)
    const isDevelopment = argv.mode === 'development'

    if (targetPlatforms.length > 0) {
        const config = createConfig(targetPlatforms, { noLint })
        return {
            ...config,
            name: 'platform',
            output: {
                filename: 'playgama-bridge.js',
                path: path.resolve(__dirname, 'dist'),
                publicPath: 'auto',
            },
            plugins: [
                ...(config.plugins ?? []),
                new webpack.optimize.LimitChunkCountPlugin({
                    maxChunks: 1,
                }),
            ],
        }
    }

    const baseConfig = createConfig([], { noLint })

    const dynamicConfig: Configuration = {
        ...baseConfig,
        name: 'dynamic',
        output: {
            ...baseConfig.output,
            publicPath: isDevelopment ? 'auto' : env.publicPath,
        },
        plugins: [
            ...(baseConfig.plugins ?? []),
        ],
    }

    const bundledConfig: Configuration = {
        ...baseConfig,
        name: 'bundled',
        plugins: [
            ...(baseConfig.plugins ?? []),
            new webpack.optimize.LimitChunkCountPlugin({
                maxChunks: 1,
            }),
        ],
    }

    // npm entry bundles (src/npm.ts): a shim that re-exports window.bridge plus
    // the public constants and types. The runtime is not bundled here; it ships
    // as dist/playgama-bridge.js and is loaded via <script> (see vite/).
    if (env.npm) {
        const singleChunk = new webpack.optimize.LimitChunkCountPlugin({ maxChunks: 1 })

        const npmEsmConfig: Configuration = {
            ...baseConfig,
            name: 'npm-esm',
            entry: './src/npm',
            experiments: { outputModule: true },
            output: {
                filename: 'playgama-bridge.esm.mjs',
                path: path.resolve(__dirname, 'dist'),
                library: { type: 'module' },
            },
            plugins: [...(baseConfig.plugins ?? []), singleChunk],
        }

        const npmCjsConfig: Configuration = {
            ...baseConfig,
            name: 'npm-cjs',
            entry: './src/npm',
            output: {
                filename: 'playgama-bridge.cjs.js',
                path: path.resolve(__dirname, 'dist'),
                library: { type: 'commonjs2' },
            },
            plugins: [...(baseConfig.plugins ?? []), singleChunk],
        }

        // Side-effect-free constants entry (`@playgama/bridge/constants`) for
        // games that load the SDK runtime via a <script> tag and only need
        // constant values in their own bundle.
        const constantsEsmConfig: Configuration = {
            ...baseConfig,
            name: 'npm-constants-esm',
            entry: './src/publicConstants',
            experiments: { outputModule: true },
            output: {
                filename: 'constants.esm.mjs',
                path: path.resolve(__dirname, 'dist'),
                library: { type: 'module' },
            },
            plugins: [...(baseConfig.plugins ?? []), singleChunk],
        }

        const constantsCjsConfig: Configuration = {
            ...baseConfig,
            name: 'npm-constants-cjs',
            entry: './src/publicConstants',
            output: {
                filename: 'constants.cjs.js',
                path: path.resolve(__dirname, 'dist'),
                library: { type: 'commonjs2' },
            },
            plugins: [...(baseConfig.plugins ?? []), singleChunk],
        }

        return [npmEsmConfig, npmCjsConfig, constantsEsmConfig, constantsCjsConfig]
    }

    return [dynamicConfig, bundledConfig]
}
